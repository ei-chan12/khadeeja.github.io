// 1. Mobile menu
const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
if (menuBtn) menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));

// 2. Dark / light mode (remembered on every page)
const themeBtn = document.getElementById('themeBtn');
try { if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark'); } catch (e) {}
if (themeBtn) themeBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  try { localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light'); } catch (e) {}
});

// 3. Purple placeholder if an image file is missing
const ph = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400"><rect width="100%" height="100%" fill="#c9a7f5"/><text x="50%" y="50%" font-family="Arial" font-size="24" fill="#1e1233" text-anchor="middle">Add your image here</text></svg>');
document.querySelectorAll('img').forEach(img => img.addEventListener('error', () => { img.src = ph; }, { once: true }));

// 4. Gallery: choose which image to show
const mainImg = document.getElementById('mainImg');
const caption = document.getElementById('caption');
document.querySelectorAll('.thumbs img').forEach(t => {
  const pick = () => {
    mainImg.src = t.dataset.full; mainImg.alt = t.alt; caption.textContent = t.dataset.caption;
    document.querySelectorAll('.thumbs img').forEach(x => x.classList.remove('selected'));
    t.classList.add('selected');
  };
  t.addEventListener('click', pick);
  t.addEventListener('keydown', e => { if (e.key === 'Enter') pick(); });
});

// 5. Interest filter buttons
const fb = document.querySelectorAll('.filters .btn');
fb.forEach(b => b.addEventListener('click', () => {
  fb.forEach(x => x.classList.remove('on')); b.classList.add('on');
  document.querySelectorAll('.tile').forEach(c =>
    c.classList.toggle('hidden', !(b.dataset.filter === 'all' || c.dataset.type === b.dataset.filter)));
}));

// 6. Home page button: a random little fact
const funBtn = document.getElementById('funBtn');
if (funBtn) {
  const facts = ['I love figuring out how technology works.', 'A good sunset can fix a bad day.', 'Big dreams start with small steps.'];
  let n = 0;
  funBtn.addEventListener('click', () => { document.getElementById('funText').textContent = facts[n++ % facts.length]; });
}
